package com.lejiyu.payroll.Entity;

public class Admin {
    private Long adminNumber;

    private String adminName;

    private String departmentNumber;

    private String departmentName;

    private Long employeeNumber;

    public Long getAdminNumber() {
        return adminNumber;
    }

    public void setAdminNumber(Long adminNumber) {
        this.adminNumber = adminNumber;
    }

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName == null ? null : adminName.trim();
    }

    public String getDepartmentNumber() {
        return departmentNumber;
    }

    public void setDepartmentNumber(String departmentNumber) {
        this.departmentNumber = departmentNumber == null ? null : departmentNumber.trim();
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName == null ? null : departmentName.trim();
    }

    public Long getEmployeeNumber() {
        return employeeNumber;
    }

    public void setEmployeeNumber(Long employeeNumber) {
        this.employeeNumber = employeeNumber;
    }
}