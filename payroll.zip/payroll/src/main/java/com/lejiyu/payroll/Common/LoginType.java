package com.lejiyu.payroll.Common;

public class LoginType {
	public static String admin = "管理员";
	public static String employee = "员工";
}
